# CFPA 模组简体中文翻译

来源：https://github.com/CFPAOrg/Minecraft-Mod-Language-Package
源码版本：6a5e51509159f9c12d5727808f7b1e42c4e05200
本包按所装模组筛选并合并 1.21 与兼容旧版词条。
许可：CC BY-NC-SA 4.0；非商业使用、署名、相同方式共享。
原作者与贡献者见上游 Git 历史。
