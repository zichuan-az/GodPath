CozyUI+：Fogg05 / https://github.com/Fogg05/CozyUI-Plus
ysnCE：依斯那 / https://github.com/mc-ysn/ysn_resourcepacks
GodPath 1.21.1 backport: HUD sprites relocated; unsupported 26.x overlays excluded.
License: GPL-3.0. Source assets retained under build/vision-research.
